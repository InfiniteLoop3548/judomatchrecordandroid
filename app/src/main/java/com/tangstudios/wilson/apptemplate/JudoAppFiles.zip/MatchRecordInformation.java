package com.tangstudios.wilson.apptemplate;

/**
 * Created by Wilson on 11/11/2015.
 */
public class MatchRecordInformation {

    String matchTitle;
    String opponentName;
    String beltColor;
    String dojo;
    String date;
    String tournament;
    String result;
    int score;
    String comments;

}
