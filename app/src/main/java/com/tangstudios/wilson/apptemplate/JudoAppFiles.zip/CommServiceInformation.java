package com.tangstudios.wilson.apptemplate;

/**
 * Created by Wilson on 3/8/2016.
 */
public class CommServiceInformation {

    String activity;
    String date;
    String tournament;
    String time;
    String sensei;

}
